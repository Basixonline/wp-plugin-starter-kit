<?php
/*
Plugin Name: Starter
Plugin URI: 
Description: This is you plugin description
Author: 
Version: 
Author URI: 
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html


/*Class and function PREFIX = Starter_ */

/***************************************/
/**********  Configuration  ************/
/***************************************/
class Starter_Config{
	/*************  General  ***************/
	/************  DONT EDIT  **************/
	/* Leave the below verialbles as is for future functionality that this plugin could perform from XPSK base*/

	/* The displayed name of your plugin */
	public $plugin_name;
	/* The alias of the plugin used by external entities */
	public $plugin_alias;
	/* Admin Menu */
	public $plugin_menu;
	
	/************* Admin Menu **************/
	/* Setup you admin menu, leave as is if you dont know what you are doing! */
	public function build_plugin_menu(){
	
		$plugin_alias  = $this->plugin_alias;
		$plugin_name  = $this->plugin_name;
				
		$this->plugin_menu = array
			(
			$this->plugin_name => array
				(
				/* PLUGIN main menu. Leave the menu slug as is for Javascript localization to the plugin and submenu items */
				'menu_page'	=>	array
					(
					//Menu item text
					'page_title' 	=> $this->plugin_name,
					'menu_title' 	=> $this->plugin_name,
					//Allocates WP role to the menu item
					'capability' 	=> 'administrator',
					//This is the admin page slug. Do not remove the xpsk- prefix. It is used to localize you JS to be kept whitin the plugin. Note:Including JS publicaly can interfare with other plugins or theme functionality
					'menu_slug' 	=> 'xpsk-'.$plugin_alias.'-main',
					//Specifies the function to be called when the menu item is opened. By default your DB view will be called by function 'Starter_main_page'
					'function' 		=> 'Starter_main_page',
					//Change your menu icon by uncommenting the below comment. Add icon (28px X 28px) in the images folder or specify path
					'icon_url' 		=> WP_PLUGIN_URL.'/'.$plugin_name.'/images/menu_icon.png',
					//Changes your menu item position. leave blank to add items to the end of the WP navigation (ordered alphabeticaly)
					'position '		=> ''
					),
				/* PLUGIN sub menus. Leave the parent page key as is! */
				/*'sub_menu_page'		=>	array
					(
					'Manage Forms' => array
						(
						'parent_slug' 	=> 'WA-'.$plugin_alias.'-main',
						'page_title' 	=> 'Manage Forms',
						'menu_title' 	=> 'Manage Forms',
						'capability' 	=> 'administrator',
						'menu_slug' 	=> 'xpsk-'.$plugin_alias.'-{ADD UNIQUE STRING HERE}',
						'function' 		=> 'WAFormBuilder_view_forms_page',
						),
					)*/
				)		
			);
		}
	
	public function __construct()
		{
		/* Dont touch this  unless you know what your doing! */
		$header_info = IZC_Functions::get_file_headers(dirname(__FILE__).DIRECTORY_SEPARATOR.'main.php');
		$this->plugin_name 		= $header_info['Plugin Name'];
		$this->plugin_alias		= IZC_Functions::format_name($this->plugin_name);
		$this->build_plugin_menu(); 
		}
}

/***************************************/
/*************  Hooks   ****************/
/***************************************/
/* On plugin activation */
/* Build admin menu. adds the menu as specified in the config class to the admin nav structure */
add_action('admin_menu', 'Starter_main_menu');
register_activation_hook(__FILE__, 'Starter_run_instalation' );
/***************************************/
/*********  Hook functions   ***********/
/***************************************/
/*********  ADMIN MENU   ***********/
/* Convert menu to WP Admin Menu */
function Starter_main_menu(){
	$config = new Starter_Config();
	IZC_Admin_menu::build_menu($config->plugin_name);
}
/*********  INSTALLATION   ***********/
function Starter_run_instalation(){
	$config = new Starter_Config();	
	$instalation = new IZC_Instalation();
	$instalation->component_menu 			=  $config->plugin_menu;
	$instalation->run_instalation('');	
}

/***************************************/
/*********   Admin Pages   *************/
/***************************************/
/* these are the functions called from your menu itmes for example if this is your menu function. 
If you are using submenu items add there functions here
 */
function Starter_main_page(){
	
}
/***************************************/
/*********   User Interface   **********/
/***************************************/
/************* OUTPUT FROM SHORTCODE **************/
function Starter_ui_output($atts){
	
}

//This is to prevent XPSK to be deactivated while this plugin is active!! DO NOT attempt to deactivate XPSK while this plugin is active.
wp_enqueue_style('xpsk-block-deactivate',  WP_PLUGIN_URL . '/xpsk/css/block_deactivation.css');
?>